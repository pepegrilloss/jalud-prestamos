<?php

namespace App\Observers;

use App\Models\ProposicionCredito;

class ProposicionCreditoObserver
{
    /**
     * Handle the ProposicionCredito "created" event.
     */
    public function created(ProposicionCredito $proposicionCredito): void
    {
        // Generar código si no existe
        if (!$proposicionCredito->CodigoCredito) {
            $proposicionCredito->update([
                'CodigoCredito' => ProposicionCredito::generarCodigoCredito(),
            ]);
        }

        // Crear las aprobaciones requeridas
        $proposicionCredito->crearAprobacionesRequeridas();
    }

    /**
     * Handle the ProposicionCredito "updated" event.
     */
    public function updated(ProposicionCredito $proposicionCredito): void
    {
        //
    }

    /**
     * Handle the ProposicionCredito "deleted" event.
     */
    public function deleted(ProposicionCredito $proposicionCredito): void
    {
        //
    }

    /**
     * Handle the ProposicionCredito "restored" event.
     */
    public function restored(ProposicionCredito $proposicionCredito): void
    {
        //
    }

    /**
     * Handle the ProposicionCredito "force deleted" event.
     */
    public function forceDeleted(ProposicionCredito $proposicionCredito): void
    {
        //
    }
}
