<?php

namespace App\Filament\Resources\ProposicionCreditoResource\Pages;

use App\Filament\Resources\ProposicionCreditoResource;
use Filament\Resources\Pages\ListRecords;

class ListProposicionCredito extends ListRecords
{
    protected static string $resource = ProposicionCreditoResource::class;

    protected static ?string $title = 'Generar Crédito';

    protected function getHeaderActions(): array
    {
        return [];
    }
}
