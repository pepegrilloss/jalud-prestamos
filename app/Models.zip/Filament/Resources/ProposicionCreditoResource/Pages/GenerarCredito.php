<?php

namespace App\Filament\Resources\ProposicionCreditoResource\Pages;

use App\Filament\Resources\ProposicionCreditoResource;
use App\Models\Credito;
use App\Models\ProposicionCredito;
use App\Models\TipoPago;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Actions;
use Filament\Resources\Pages\Page;

class GenerarCredito extends Page
{
    protected static string $resource = ProposicionCreditoResource::class;

    protected static ?string $title = 'Generar Crédito';

    public ?ProposicionCredito $proposicion = null;

    public function mount($record): void
    {
        $this->proposicion = ProposicionCredito::with([
            'cliente',
            'tipoCredito',
        ])->findOrFail($record);
        
        if ($this->proposicion->Estado !== 'APROBADO') {
            redirect()->route('filament.admin.resources.proposicion-credito.index')
                ->with('error', 'La proposición debe estar aprobada para generar crédito.');
        }

        if ($this->proposicion->credito()->exists()) {
            redirect()->route('filament.admin.resources.proposicion-credito.index')
                ->with('error', 'Esta proposición ya tiene un crédito generado.');
        }
    }

    public function form(Form $form): Form
    {
        $proposicion = $this->proposicion;

        return $form
            ->schema([
                Forms\Components\Section::make('Información de la Proposición')
                    ->schema([
                        Forms\Components\TextInput::make('codigo')
                            ->label('Código de Crédito')
                            ->default($proposicion->CodigoCredito)
                            ->readOnly(),

                        Forms\Components\TextInput::make('cliente')
                            ->label('Cliente')
                            ->default($proposicion->cliente->NombresApellidos)
                            ->readOnly(),

                        Forms\Components\TextInput::make('dni')
                            ->label('DNI')
                            ->default($proposicion->cliente->DNI)
                            ->readOnly(),

                        Forms\Components\TextInput::make('tipo_credito')
                            ->label('Tipo de Crédito')
                            ->default($proposicion->tipoCredito->Descripcion)
                            ->readOnly(),

                        Forms\Components\TextInput::make('monto_total')
                            ->label('Monto Total')
                            ->default('S/. ' . number_format($proposicion->MontoTotal, 2))
                            ->readOnly(),

                        Forms\Components\TextInput::make('tasa_interes')
                            ->label('Tasa (%)')
                            ->default(number_format($proposicion->TasaInteres, 2))
                            ->readOnly(),

                        Forms\Components\TextInput::make('plazo')
                            ->label('Plazo (días)')
                            ->default((string)$proposicion->Plazo)
                            ->readOnly(),

                        Forms\Components\TextInput::make('numero_cuotas')
                            ->label('Número de Cuotas')
                            ->default((string)$proposicion->NumeroCuotas)
                            ->readOnly(),

                        Forms\Components\TextInput::make('monto_cuota')
                            ->label('Monto por Cuota')
                            ->default('S/. ' . number_format($proposicion->MontoCuota, 2))
                            ->readOnly(),

                        Forms\Components\TextInput::make('monto_interes')
                            ->label('Monto Total de Interés')
                            ->default('S/. ' . number_format($proposicion->MontoInteres, 2))
                            ->readOnly(),

                        Forms\Components\TextInput::make('monto_pagar')
                            ->label('Monto Total a Pagar')
                            ->default('S/. ' . number_format($proposicion->MontoTotal + $proposicion->MontoInteres, 2))
                            ->readOnly(),

                        Forms\Components\TextInput::make('tasa_mora')
                            ->label('Tasa de Mora (%)')
                            ->default(number_format($proposicion->TasaMora, 2))
                            ->readOnly(),
                    ])
                    ->columns(2),

                Forms\Components\Section::make('Generación de Crédito')
                    ->schema([
                        Forms\Components\Select::make('tipo_pago_id')
                            ->label('Tipo de Pago')
                            ->options(
                                TipoPago::where('Activo', true)
                                    ->pluck('Nombre', 'TipoPagoID')
                            )
                            ->required()
                            ->searchable()
                            ->native(false),

                        Forms\Components\Textarea::make('comentario_generacion')
                            ->label('Comentario de Generación')
                            ->rows(4)
                            ->maxLength(500),
                    ])
                    ->columns(1),
            ]);
    }

    protected function getFormActions(): array
    {
        return [
            Actions\Action::make('crear')
                ->label('Crear')
                ->color('success')
                ->action('guardarCredito'),
            
            Actions\Action::make('cancelar')
                ->label('Cancelar')
                ->color('gray')
                ->url(ProposicionCreditoResource::getUrl('index')),
        ];
    }

    public function guardarCredito(): void
    {
        $data = $this->form->getState();

        Credito::create([
            'ProposicionCreditoID' => $this->proposicion->ProposicionCreditoID,
            'TipoPagoID' => $data['tipo_pago_id'],
            'ComentarioGeneracion' => $data['comentario_generacion'] ?? null,
            'FechaGeneracion' => now(),
            'UserGeneracionID' => auth()->id(),
            'Activo' => true,
        ]);

        redirect()->route('filament.admin.resources.creditos.index')
            ->with('success', 'Crédito generado exitosamente');
    }
}



