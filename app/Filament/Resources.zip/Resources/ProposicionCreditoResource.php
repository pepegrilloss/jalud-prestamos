<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ProposicionCreditoResource\Pages;
use App\Models\ProposicionCredito;
use App\Models\Cliente;
use App\Models\TipoCredito;
use App\Models\Tasa;
use App\Models\Zona;
use App\Models\NivelAprobacion;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Forms\Get;
use Filament\Forms\Set;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Support\Facades\Crypt;

class ProposicionCreditoResource extends Resource
{
    protected static ?string $model = ProposicionCredito::class;

    protected static ?string $navigationGroup = 'Créditos';
    protected static ?string $navigationIcon = 'heroicon-o-document-text';
    protected static ?int $navigationSort = 10;

    protected static ?string $navigationLabel = 'Proposición de Créditos';
    protected static ?string $modelLabel = 'Proposición de Crédito';
    protected static ?string $pluralModelLabel = 'Proposiciones de Crédito';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('Detalles del Crédito')
                    ->schema([
                        Forms\Components\Select::make('ClienteID')
                            ->label('Cliente')
                            ->options(
                                Cliente::where('Activo', true)
                                    ->orderBy('NombresApellidos')
                                    ->get()
                                    ->mapWithKeys(fn($cliente) => [
                                        $cliente->ClienteID => "{$cliente->NombresApellidos} (DNI: {$cliente->DNI})"
                                    ])
                            )
                            ->required()
                            ->searchable()
                            ->preload()
                            ->native(false)
                            ->columnSpanFull()
                            ->default(function () {
                                try {
                                    if ($encrypted = request()->query('cliente')) {
                                        session()->put('cliente_predefinido', true);
                                        return Crypt::decrypt($encrypted);
                                    }
                                } catch (\Exception $e) {
                                    return null;
                                }
                            })
                            ->disabled(fn() => session()->has('cliente_predefinido'))
                            ->dehydrated()
                            ->live(debounce: 0)
                            ->afterStateUpdated(function (Set $set, $state, Get $get) {
                                if ($state) {
                                    $cliente = Cliente::find($state);
                                    if ($cliente) {
                                        $set('CodigoCliente', $cliente->DNI);
                                        $set('ZonaID', $cliente->ZonaID);
                                    }
                                }
                            }),

                        Forms\Components\TextInput::make('CodigoCliente')
                            ->label('Código Cliente')
                            ->disabled()
                            ->dehydrated()
                            ->hidden(),

                        Forms\Components\TextInput::make('CodigoCredito')
                            ->label('Código de Crédito')
                            ->disabled()
                            ->dehydrated()
                            ->default(fn() => ProposicionCredito::generarCodigoCredito())
                            ->columnSpanFull(),

                        Forms\Components\Select::make('TipoCreditoID')
                            ->label('Tipo de Crédito')
                            ->options(
                                TipoCredito::where('Activo', true)
                                    ->pluck('Descripcion', 'TipoCreditoID')
                            )
                            ->required()
                            ->searchable()
                            ->native(false),

                        Forms\Components\TextInput::make('MontoTotal')
                            ->label('Monto Total')
                            ->required()
                            ->numeric()
                            ->prefix('S/')
                            ->step(0.01)
                            ->live(onBlur: true)
                            ->validationMessages([
                                'max' => 'El monto excede el límite máximo permitido para tu nivel de aprobación',
                                'min' => 'El monto es menor al mínimo permitido para tu nivel de aprobación',
                            ])
                            ->rules([
                                function () {
                                    return function ($attribute, $value, $fail) {
                                        if (!$value)
                                            return;

                                        $nivelActual = auth()->user()->getNivelAprobacionActivo();
                                        if (!$nivelActual) {
                                            $fail('No tienes un nivel de aprobación asignado');
                                            return;
                                        }

                                        $nivel = $nivelActual->nivelAprobacion;
                                        if ($value < $nivel->MontoMinimo) {
                                            $fail("El monto mínimo permitido es S/ {$nivel->MontoMinimo}");
                                        }
                                        if ($value > $nivel->MontoMaximo) {
                                            $fail("El monto máximo permitido es S/ {$nivel->MontoMaximo}");
                                        }
                                    };
                                }
                            ])
                            ->helperText(function () {
                                $nivelActual = auth()->user()->getNivelAprobacionActivo();
                                if ($nivelActual) {
                                    $nivel = $nivelActual->nivelAprobacion;
                                    return "Rango permitido: S/ {$nivel->MontoMinimo} - S/ {$nivel->MontoMaximo}";
                                }
                                return 'No tienes nivel de aprobación asignado';
                            })
                            ->afterStateUpdated(function (Set $set, $state, Get $get) {
                                if ($state) {
                                    $nivel = ProposicionCredito::obtenerNivelAprobacionRequerido($state);
                                    $set('NivelAprobacionRequerido', $nivel?->NivelAprobacionID);

                                    if ($get('TasaInteres') && $get('NumeroCuotas')) {
                                        $montoTotal = $state;
                                        $tasaInteres = (float)$get('TasaInteres');
                                        $numeroCuotas = (int)$get('NumeroCuotas');
                                        
                                        $montoInteres = $montoTotal * ($tasaInteres / 100);
                                        $montoTotal += $montoInteres;
                                        $montoCuota = $montoTotal / $numeroCuotas;
                                        
                                        $set('MontoCuota', round($montoCuota, 2));
                                        $set('MontoInteres', round($montoInteres, 2));
                                    }
                                }
                            }),

                        Forms\Components\Select::make('TasaID')
                            ->label('Tasa de Interés')
                            ->options(
                                Tasa::where('Activo', true)
                                    ->get()
                                    ->mapWithKeys(fn($tasa) => [
                                        $tasa->TasaID => "{$tasa->Nombre} - {$tasa->Valor}%"
                                    ])
                            )
                            ->required()
                            ->searchable()
                            ->native(false)
                            ->live()
                            ->afterStateUpdated(function (Set $set, $state, Get $get) {
                                if ($state) {
                                    $tasa = Tasa::find($state);
                                    $set('TasaInteres', $tasa->Valor);

                                    if ($get('MontoTotal') && $get('NumeroCuotas')) {
                                        $montoTotal = (float)$get('MontoTotal');
                                        $tasaInteres = (float)$tasa->Valor;
                                        $numeroCuotas = (int)$get('NumeroCuotas');
                                        
                                        $montoInteres = $montoTotal * ($tasaInteres / 100);
                                        $montoConInteres = $montoTotal + $montoInteres;
                                        $montoCuota = $montoConInteres / $numeroCuotas;
                                        
                                        $set('MontoCuota', round($montoCuota, 2));
                                        $set('MontoInteres', round($montoInteres, 2));
                                    }
                                }
                            }),

                        Forms\Components\TextInput::make('TasaInteres')
                            ->label('Tasa de Interés (%)')
                            ->numeric()
                            ->step(0.01)
                            ->disabled()
                            ->dehydrated(),

                        Forms\Components\TextInput::make('Plazo')
                            ->label('Plazo (días)')
                            ->required()
                            ->numeric()
                            ->integer()
                            ->step(1)
                            ->minValue(1)
                            ->helperText('Plazo en días para el crédito'),

                        Forms\Components\TextInput::make('NumeroCuotas')
                            ->label('Número de Cuotas')
                            ->required()
                            ->numeric()
                            ->integer()
                            ->step(1)
                            ->minValue(1)
                            ->helperText('Cantidad de cuotas en las que se dividirá el crédito')
                            ->live(onBlur: true)
                            ->afterStateUpdated(function (Set $set, $state, Get $get) {
                                if ($state && $get('MontoTotal') && $get('TasaInteres')) {
                                    $montoTotal = (float)$get('MontoTotal');
                                    $tasaInteres = (float)$get('TasaInteres');
                                    $numeroCuotas = (int)$state;
                                    
                                    $montoInteres = $montoTotal * ($tasaInteres / 100);
                                    $montoConInteres = $montoTotal + $montoInteres;
                                    $montoCuota = $montoConInteres / $numeroCuotas;
                                    
                                    $set('MontoCuota', round($montoCuota, 2));
                                    $set('MontoInteres', round($montoInteres, 2));
                                }
                            }),

                        Forms\Components\TextInput::make('MontoCuota')
                            ->label('Monto por Cuota')
                            ->numeric()
                            ->prefix('S/')
                            ->step(0.01)
                            ->disabled()
                            ->dehydrated(),

                        Forms\Components\TextInput::make('MontoInteres')
                            ->label('Monto Total de Interés')
                            ->numeric()
                            ->prefix('S/')
                            ->step(0.01)
                            ->disabled()
                            ->dehydrated(),

                        Forms\Components\TextInput::make('TasaMora')
                            ->label('Tasa de Mora (%)')
                            ->required()
                            ->numeric()
                            ->step(0.01)
                            ->default(0.00)
                            ->prefix('%')
                            ->helperText('Porcentaje aplicado por mora en los pagos'),
                    ])
                    ->columns(3),

                Forms\Components\Section::make('Información Adicional')
                    ->schema([
                        Forms\Components\Select::make('ZonaID')
                            ->label('Zona')
                            ->options(Zona::where('Activo', true)->pluck('Nombre', 'ZonaID'))
                            ->searchable()
                            ->native(false),

                        Forms\Components\Textarea::make('Observaciones')
                            ->rows(3)
                            ->maxLength(65535)
                            ->columnSpanFull()
                            ->placeholder('Observaciones adicionales sobre la proposición'),
                    ])
                    ->columns(2),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('CodigoCredito')
                    ->label('Código')
                    ->searchable()
                    ->sortable()
                    ->copyable(),

                Tables\Columns\TextColumn::make('cliente.NombresApellidos')
                    ->label('Cliente')
                    ->searchable()
                    ->sortable(),

                Tables\Columns\TextColumn::make('tipoCredito.Descripcion')
                    ->label('Tipo de Crédito')
                    ->searchable()
                    ->toggleable(),

                Tables\Columns\TextColumn::make('MontoTotal')
                    ->label('Monto')
                    ->money('PEN')
                    ->sortable(),

                Tables\Columns\TextColumn::make('NumeroCuotas')
                    ->label('Cuotas')
                    ->sortable()
                    ->toggleable(),

                Tables\Columns\TextColumn::make('MontoCuota')
                    ->label('Cuota')
                    ->money('PEN')
                    ->toggleable(),

                Tables\Columns\TextColumn::make('Estado')
                    ->badge()
                    ->color(fn(string $state): string => match ($state) {
                        'PENDIENTE' => 'warning',
                        'APROBADO' => 'info',
                        'RECHAZADO' => 'danger',
                        'DESEMBOLSADO' => 'success',
                        'CANCELADO' => 'gray',
                    })
                    ->sortable(),

                Tables\Columns\TextColumn::make('userProponente.name')
                    ->label('Proponente')
                    ->searchable()
                    ->toggleable(),

                Tables\Columns\TextColumn::make('FechaPropuesta')
                    ->label('Fecha Propuesta')
                    ->dateTime('d/m/Y H:i')
                    ->sortable()
                    ->toggleable(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('Estado')
                    ->options([
                        'PENDIENTE' => 'Pendiente',
                        'APROBADO' => 'Aprobado',
                        'RECHAZADO' => 'Rechazado',
                        'DESEMBOLSADO' => 'Desembolsado',
                        'CANCELADO' => 'Cancelado',
                    ]),

                Tables\Filters\SelectFilter::make('TipoCreditoID')
                    ->label('Tipo de Crédito')
                    ->options(TipoCredito::where('Activo', true)->pluck('Descripcion', 'TipoCreditoID'))
                    ->searchable(),
            ])
            ->actions([
                Tables\Actions\ActionGroup::make([
                    Tables\Actions\ViewAction::make(),
                    Tables\Actions\EditAction::make(),
                    Tables\Actions\Action::make('aprobar')
                        ->label('Aprobar')
                        ->icon('heroicon-o-check-circle')
                        ->color('success')
                        ->visible(fn($record) => $record->Estado === 'PENDIENTE')
                        ->requiresConfirmation()
                        ->form([
                            Forms\Components\Textarea::make('ComentarioAprobacion')
                                ->label('Comentario')
                                ->rows(3)
                                ->maxLength(500)
                                ->required(),
                        ])
                        ->action(function (ProposicionCredito $record, array $data) {
                            $record->update([
                                'Estado' => 'APROBADO',
                                'UserAprobadorID' => auth()->id(),
                                'FechaAprobacion' => now(),
                                'ComentarioAprobacion' => $data['ComentarioAprobacion'],
                            ]);
                            \Filament\Notifications\Notification::make()
                                ->success()
                                ->title('Crédito Aprobado')
                                ->body('La proposición ha sido aprobada correctamente')
                                ->send();
                        }),

                    Tables\Actions\Action::make('rechazar')
                        ->label('Rechazar')
                        ->icon('heroicon-o-x-circle')
                        ->color('danger')
                        ->visible(fn($record) => $record->Estado === 'PENDIENTE')
                        ->requiresConfirmation()
                        ->form([
                            Forms\Components\Textarea::make('ComentarioAprobacion')
                                ->label('Motivo del Rechazo')
                                ->rows(3)
                                ->maxLength(500)
                                ->required(),
                        ])
                        ->action(function (ProposicionCredito $record, array $data) {
                            $record->update([
                                'Estado' => 'RECHAZADO',
                                'UserAprobadorID' => auth()->id(),
                                'FechaAprobacion' => now(),
                                'ComentarioAprobacion' => $data['ComentarioAprobacion'],
                            ]);
                            \Filament\Notifications\Notification::make()
                                ->success()
                                ->title('Crédito Rechazado')
                                ->body('La proposición ha sido rechazada')
                                ->send();
                        }),
                ]),
            ])
            ->recordUrl(null)
            ->defaultSort('FechaPropuesta', 'desc')
            ->paginationPageOptions([10, 25, 50]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListProposicionCreditos::route('/'),
            'create' => Pages\CreateProposicionCredito::route('/create'),
            'view' => Pages\ViewProposicionCredito::route('/{record}'),
            'edit' => Pages\EditProposicionCredito::route('/{record}/edit'),
        ];
    }
}
