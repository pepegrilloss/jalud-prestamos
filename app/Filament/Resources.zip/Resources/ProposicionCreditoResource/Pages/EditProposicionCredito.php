<?php

namespace App\Filament\Resources\ProposicionCreditoResource\Pages;

use App\Filament\Resources\ProposicionCreditoResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditProposicionCredito extends EditRecord
{
    protected static string $resource = ProposicionCreditoResource::class;

    protected function mutateFormDataBeforeSave(array $data): array
    {
        $data['FechaModificacion'] = now();
        $data['UserModificacionID'] = auth()->id();
        return $data;
    }

    protected function getHeaderActions(): array
    {
        return [
            Actions\ViewAction::make(),
        ];
    }
}
