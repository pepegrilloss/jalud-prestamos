<?php

namespace App\Filament\Resources\ProposicionCreditoResource\Pages;

use App\Filament\Resources\ProposicionCreditoResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewProposicionCredito extends ViewRecord
{
    protected static string $resource = ProposicionCreditoResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\EditAction::make(),
        ];
    }
}
