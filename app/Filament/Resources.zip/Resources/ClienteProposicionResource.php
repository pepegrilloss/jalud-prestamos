<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ClienteProposicionResource\Pages;
use App\Filament\Resources\ProposicionCreditoResource;
use App\Models\Cliente;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Support\Facades\Crypt;

class ClienteProposicionResource extends Resource
{
    protected static ?string $model = Cliente::class;

    protected static ?string $navigationGroup = 'Créditos';
    protected static ?string $navigationIcon = 'heroicon-o-users';
    protected static ?int $navigationSort = 9;

    protected static ?string $navigationLabel = 'Clientes - Nueva Proposición';
    protected static ?string $modelLabel = 'Cliente';
    protected static ?string $pluralModelLabel = 'Clientes para Proposición';

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('DNI')
                    ->label('DNI')
                    ->searchable()
                    ->sortable()
                    ->copyable(),

                Tables\Columns\TextColumn::make('NombresApellidos')
                    ->label('Nombres y Apellidos')
                    ->searchable()
                    ->sortable()
                    ->weight('bold'),


                Tables\Columns\TextColumn::make('zona.Nombre')
                    ->label('Zona')
                    ->searchable()
                    ->sortable()
                    ->toggleable(),

                Tables\Columns\TextColumn::make('proposiciones_count')
                    ->label('Proposiciones')
                    ->counts('proposiciones')
                    ->sortable()
                    ->badge()
                    ->color('info'),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('ZonaID')
                    ->label('Zona')
                    ->relationship('zona', 'Nombre')
                    ->searchable(),

                Tables\Filters\TernaryFilter::make('Activo')
                    ->label('Estado')
                    ->placeholder('Todos')
                    ->trueLabel('Activos')
                    ->falseLabel('Inactivos'),
            ])
            ->actions([
                Tables\Actions\ActionGroup::make([
                    Tables\Actions\Action::make('nueva_proposicion')
                        ->label('Nueva Proposición')
                        ->icon('heroicon-o-document-plus')
                        ->color('success')
                        ->url(fn (Cliente $record): string => 
                            ProposicionCreditoResource::getUrl('create', ['cliente' => Crypt::encrypt($record->ClienteID)])
                        )
                        ->visible(fn (Cliente $record) => $record->Activo),

                    Tables\Actions\Action::make('ver_proposiciones')
                        ->label('Ver Proposiciones')
                        ->icon('heroicon-o-document-text')
                        ->color('info')
                        ->url(fn (Cliente $record): string => 
                            ProposicionCreditoResource::getUrl('index') . '?tableFilters[cliente][value]=' . $record->ClienteID
                        )
                        ->visible(fn (Cliente $record) => $record->proposiciones_count > 0),
                ]),
            ])
            ->defaultSort('NombresApellidos', 'asc')
            ->paginationPageOptions([10, 25, 50, 100])
            ->poll('30s'); // Actualiza cada 30 segundos
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListClienteProposicions::route('/'),
        ];
    }

    public static function canCreate(): bool
    {
        return false;
    }
}