<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Traits\BelongsToSede;

class AnalisisEconomico extends Model
{
    use BelongsToSede;
    protected $table = 'AnalisisEconomico';
    protected $primaryKey = 'AnalisisEconomicoID';
    public $timestamps = false;

    protected $fillable = [
        'ClienteID',
        'CapitalManifestado',
        'CapitalEstimado',
        'VentaManifestadaMin',
        'VentaManifestadaMax',
        'VentaEstimada',
        'MontoMaxRecomendado',
        'FechaAnalisis',
        'UsuarioAnalisis',
        'FechaModificacion',
        'UsuarioModificacion',
        'FechaCierre',
        'Activo',
        'SedeID',
    ];

    protected $casts = [
        'CapitalManifestado' => 'decimal:2',
        'CapitalEstimado' => 'decimal:2',
        'VentaManifestadaMin' => 'decimal:2',
        'VentaManifestadaMax' => 'decimal:2',
        'VentaEstimada' => 'decimal:2',
        'MontoMaxRecomendado' => 'decimal:2',
        'FechaAnalisis' => 'datetime',
        'FechaModificacion' => 'datetime',
        'FechaCierre' => 'datetime',
        'Activo' => 'boolean',
    ];

    public function cliente(): BelongsTo
    {
        return $this->belongsTo(Cliente::class, 'ClienteID', 'ClienteID');
    }
}