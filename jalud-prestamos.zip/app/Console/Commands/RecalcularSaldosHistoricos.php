<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\FondoSede;
use App\Models\MovimientoFondo;
use App\Models\TransferenciaSede;
use App\Models\Credito;
use App\Models\Pago;

class RecalcularSaldosHistoricos extends Command
{
    protected $signature = 'fondos:recalcular-historico';
    protected $description = 'Limpia los movimientos antiguos y recalcula el saldo de Trujillo asumiendo una inyección de 200,000 soles';

    public function handle()
    {
        $this->info("Iniciando recalculo de saldos históricos...");

        // Encontrar los IDs correctos dinámicamente
        $gerenciaSede = \App\Models\Sede::where('Nombre', 'like', '%Gerencia%')->first();
        $trujilloSede = \App\Models\Sede::where('Nombre', 'like', '%Trujillo%')->first();

        if (!$gerenciaSede || !$trujilloSede) {
            $this->error("No se pudo encontrar la sede de Gerencia o Trujillo en la base de datos.");
            return 1;
        }

        $gerenciaSedeId = $gerenciaSede->SedeID;
        $trujilloSedeId = $trujilloSede->SedeID;

        // Limpiar Chiclayo si se actualizó por error en la ejecución anterior
        $chiclayoSede = \App\Models\Sede::where('Nombre', 'like', '%Chiclayo%')->first();
        if ($chiclayoSede) {
            $chiclayo = FondoSede::where('SedeID', $chiclayoSede->SedeID)->first();
            if ($chiclayo && $gerenciaSedeId != $chiclayoSede->SedeID) {
                $chiclayo->update(['Saldo' => 0, 'SaldoCajaChica' => 0]);
            }
        }

        // 1. Regularizar pagos antiguos: los pagos generados por Extornos/Resoluciones
        // (SolicitudResolucionID != null) NO son pagos a mayor reales. Solo los pagos
        // registrados manualmente como MAYOR son "Cuenta a Mayor" devolvible.
        // No se modifica EsPagoAMayor aqui: los asientos de resolucion se identifican
        // por SolicitudResolucionID en reportes y saldos.
        $this->line("Pagos de extornos: identificados por SolicitudResolucionID (sin tocar EsPagoAMayor).");

        // 2. Inyectar o corregir la transferencia inicial de 200,000 hacia Trujillo
        // Buscamos si ya existe la transferencia inicial para no duplicarla ni borrar otras reales
        $transferencia = TransferenciaSede::where('SedeDestinoID', $trujilloSedeId)
            ->where('Monto', 200000)
            ->first();

        $fechaInicial = '2026-04-06 08:00:00'; // Fecha en la que arrancaron los primeros créditos

        if ($transferencia) {
            $transferencia->update([
                'FechaTransferencia' => $fechaInicial,
                'FechaRespuesta' => $fechaInicial,
                'created_at' => $fechaInicial,
                'updated_at' => $fechaInicial
            ]);
            $this->line("Transferencia de 200,000 existente actualizada a fecha inicial: {$fechaInicial}.");
        } else {
            $transferencia = TransferenciaSede::create([
                'SedeOrigenID' => $gerenciaSedeId,
                'SedeDestinoID' => $trujilloSedeId,
                'Monto' => 200000,
                'Estado' => 'ACEPTADO',
                'UsuarioOrigenID' => 1,
                'UsuarioRespondeID' => 1,
                'FechaTransferencia' => $fechaInicial,
                'FechaRespuesta' => $fechaInicial,
                'CuentaOrigen' => 'CAJA_ABIERTA',
                'CuentaDestino' => 'CAJA_ABIERTA',
                'created_at' => $fechaInicial,
                'updated_at' => $fechaInicial
            ]);
            $this->line("Transferencia oficial de 200,000 creada en la fecha: {$fechaInicial}.");
        }

        // Buscar el movimiento de fondo inicial o crearlo
        $movimiento = MovimientoFondo::where('SedeID', $trujilloSedeId)
            ->where('Tipo', 'RECEPCION_TRANSFERENCIA')
            ->where('Monto', 200000)
            ->first();

        if ($movimiento) {
            $movimiento->update([
                'created_at' => $fechaInicial,
                'updated_at' => $fechaInicial
            ]);
        } else {
            MovimientoFondo::create([
                'SedeID' => $trujilloSedeId,
                'Tipo' => 'RECEPCION_TRANSFERENCIA',
                'Monto' => 200000,
                'SaldoAnterior' => 0,
                'SaldoNuevo' => 200000,
                'TransferenciaID' => $transferencia->TransferenciaID,
                'UsuarioID' => 1,
                'Observacion' => 'Capital inicial inyectado por Gerencia',
                'created_at' => $fechaInicial,
                'updated_at' => $fechaInicial
            ]);
        }

        // 4. Calcular prestamos de Trujillo
        $prestadoCapital = Credito::withoutGlobalScopes()
            ->whereHas('proposicion', function($q) use ($trujilloSedeId) { $q->where('SedeID', $trujilloSedeId); })
            ->where('Activo', true)
            ->with('proposicion')
            ->get()
            ->sum(function($c) { return $c->proposicion->MontoTotal; });

        $saldoActual = 200000 - $prestadoCapital;

        MovimientoFondo::updateOrCreate(
            [
                'SedeID' => $trujilloSedeId,
                'Tipo' => 'EGRESO_COLOCACION',
                'Observacion' => 'Histórico: Consolidado de todos los créditos emitidos'
            ],
            [
                'Monto' => -$prestadoCapital,
                'SaldoAnterior' => 200000,
                'SaldoNuevo' => $saldoActual,
                'UsuarioID' => 1
            ]
        );

        // 5. Calcular pagos recaudados en Trujillo (SOLO DINERO FÍSICO REAL)
        // Ignoramos los pagos virtuales generados por Extornos/Excedentes (SolicitudResolucionID != null)
        // y los pagos a mayor (reales y virtuales): no son amortización aplicada a cuotas.
        $pagosRecaudados = Pago::where('SedeID', $trujilloSedeId)
            ->where('Activo', true)
            ->whereNull('SolicitudResolucionID')
            ->where('EsPagoAMayor', false)
            ->where('EsPagoAMayorPorMora', false)
            ->sum('MontoPagado');

        // Calcular los Pagos a Mayor solo para reporte en consola
        $pagosAMayor = Pago::where('SedeID', $trujilloSedeId)
            ->where('Activo', true)
            ->where('EsPagoAMayor', true)
            ->sum('MontoPagado');

        $saldoFinal = $saldoActual + $pagosRecaudados;

        MovimientoFondo::updateOrCreate(
            [
                'SedeID' => $trujilloSedeId,
                'Tipo' => 'INGRESO_RECAUDO',
                'Observacion' => 'Histórico: Consolidado de todos los pagos físicos recibidos'
            ],
            [
                'Monto' => $pagosRecaudados,
                'SaldoAnterior' => $saldoActual,
                'SaldoNuevo' => $saldoFinal,
                'UsuarioID' => 1
            ]
        );

        // 6. Actualizar FondoSede Trujillo
        $trujillo = FondoSede::updateOrCreate(
            ['SedeID' => $trujilloSedeId],
            [
                'Saldo' => $saldoFinal,
                'SaldoCajaChica' => 0
            ]
        );

        $this->info("=================================================");
        $this->info(" RECALCULO COMPLETADO EXITOSAMENTE EN TRUJILLO");
        $this->info("=================================================");
        $this->line("Inyección Base        : S/ 200,000.00");
        $this->line("Créditos Otorgados    : S/ -" . number_format($prestadoCapital, 2));
        $this->line("Pagos Físicos Recup.  : S/ +" . number_format($pagosRecaudados, 2));
        $this->info("-------------------------------------------------");
        $this->line("Cuenta a Mayor (Virtual): S/  " . number_format($pagosAMayor, 2) . " (Aislado, no suma a caja)");
        $this->info("-------------------------------------------------");
        $this->info("SALDO FÍSICO EN CAJA  : S/ " . number_format($saldoFinal, 2));
        $this->info("=================================================");

        return 0;
    }
}
