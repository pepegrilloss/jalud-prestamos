<?php

namespace App\Filament\Resources;

use App\Filament\Resources\GastoResource\Pages;
use App\Models\Gasto;
use App\Models\Motivo;
use App\Models\Proveedor;
use App\Models\Sede;
use App\Models\TipoComprobanteGasto;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Forms\Get;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class GastoResource extends Resource
{
    protected static ?string $model = Gasto::class;

    protected static ?string $navigationGroup = 'Compras y Gastos';

    protected static ?string $navigationIcon = 'heroicon-o-banknotes';

    protected static ?int $navigationSort = 2003;

    protected static ?string $label = 'Gasto';

    protected static ?string $pluralLabel = 'Gastos';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('Información del Comprobante')
                    ->schema([
                        Forms\Components\Select::make('TipoComprobanteGastoID')
                            ->prefixIcon('heroicon-m-document-text')
                            ->label('Tipo de Comprobante')
                            ->options(TipoComprobanteGasto::where('Activo', true)->pluck('Nombre', 'TipoComprobanteGastoID'))
                            ->required()
                            ->searchable()
                            ->createOptionForm([
                                Forms\Components\TextInput::make('Nombre')
                                    ->label('Nombre del Comprobante')
                                    ->required()
                                    ->maxLength(100),
                            ])
                            ->createOptionUsing(function (array $data): string {
                                $data['Activo'] = true;
                                $comprobante = TipoComprobanteGasto::create($data);

                                return $comprobante->TipoComprobanteGastoID;
                            }),
                        Forms\Components\TextInput::make('Numero')
                            ->prefixIcon('heroicon-m-hashtag')
                            ->label('Número')
                            ->required()
                            ->maxLength(20),
                        Forms\Components\DatePicker::make('FechaEmision')
                            ->prefixIcon('heroicon-m-calendar-days')
                            ->label('Fecha Emisión')
                            ->required(),
                    ])->columns(3),

                Forms\Components\Section::make('Datos del Gasto')
                    ->schema([
                        Forms\Components\Select::make('ProveedorID')
                            ->prefixIcon('heroicon-m-building-storefront')
                            ->label('Proveedor')
                            ->options(Proveedor::where('Activo', true)->pluck('Nombre', 'ProveedorID'))
                            ->required()
                            ->searchable()
                            ->createOptionForm([
                                Forms\Components\TextInput::make('Codigo')
                                    ->label('Código')
                                    ->required()
                                    ->maxLength(20),
                                Forms\Components\TextInput::make('Nombre')
                                    ->label('Nombre / Razón Social')
                                    ->required()
                                    ->maxLength(400),
                                Forms\Components\TextInput::make('RUC')
                                    ->label('RUC')
                                    ->required()
                                    ->maxLength(20),
                                Forms\Components\TextInput::make('Direccion')
                                    ->label('Dirección')
                                    ->required()
                                    ->maxLength(400),
                                Forms\Components\TextInput::make('Telefono')
                                    ->label('Teléfono')
                                    ->maxLength(20),
                            ])
                            ->createOptionUsing(function (array $data): string {
                                $proveedor = Proveedor::create($data);

                                return $proveedor->ProveedorID;
                            }),
                        Forms\Components\Select::make('MotivoID')
                            ->prefixIcon('heroicon-m-tag')
                            ->label('Motivo')
                            ->options(Motivo::where('Activo', true)->pluck('Nombre', 'MotivoID'))
                            ->required()
                            ->searchable(),
                        Forms\Components\Hidden::make('MetodoGasto')
                            ->default('CAJA CHICA'),
                        Forms\Components\Select::make('OrigenTesoreria')
                            ->label('Origen del dinero')
                            ->options(fn () => app(\App\Services\TesoreriaGerenciaService::class)->opcionesCuentas())
                            ->default(\App\Services\TesoreriaGerenciaService::CAJA_GERENCIA_KEY)
                            ->afterStateHydrated(function (Forms\Components\Select $component, ?Gasto $record): void {
                                if (! $record) {
                                    return;
                                }
                                $referencia = app(\App\Services\TesoreriaGerenciaService::class)
                                    ->referenciaDocumento($record->OrigenTesoreriaTipo, $record->CuentaTesoreriaID);
                                $component->state($referencia);
                            })
                            ->searchable()
                            ->required(fn (?Gasto $record) => ! $record || (bool) $record->OrigenTesoreriaTipo)
                            ->disabled(fn (?Gasto $record) => $record && ! $record->OrigenTesoreriaTipo)
                            ->visible(fn () => static::esPanelGerencia())
                            ->helperText('El gasto se descontará de esta cuenta. Los registros anteriores conservan su caja original.'),
                        Forms\Components\Toggle::make('EsGasto')
                            ->label('¿Es gasto?')
                            ->inline(false)
                            ->default(true)
                            ->onIcon('heroicon-m-check')
                            ->offIcon('heroicon-m-x-mark'),
                    ])->columns(4),

                Forms\Components\Section::make('Detalle del Gasto')
                    ->schema([
                        Forms\Components\Repeater::make('detalles')
                            ->label('Líneas de Gasto')
                            ->relationship()
                            ->live(debounce: 500)
                            ->schema([
                                Forms\Components\TextInput::make('Descripcion')
                                    ->prefixIcon('heroicon-m-bars-3-bottom-left')
                                    ->label('Descripción')
                                    ->required()
                                    ->maxLength(500)

                                    ->columnSpan(2),
                                Forms\Components\TextInput::make('Monto')
                                    ->label('Monto')
                                    ->numeric()
                                    ->required()
                                    ->step(0.01)
                                    ->prefix('S/. ')
                                    ->live(debounce: 500),
                            ])
                            ->columns(3)
                            ->defaultItems(1)
                            ->addActionLabel('Agregar línea de gasto')
                            ->reorderable(false)
                            ->required()
                            ->minItems(1)
                            ->columnSpanFull(),

                        Forms\Components\Placeholder::make('TotalDisplay')
                            ->label('TOTAL')
                            ->content(function (Get $get): string {
                                $detalles = $get('detalles') ?? [];
                                $total = collect($detalles)->sum(fn ($item) => floatval($item['Monto'] ?? 0));

                                return 'S/. '.number_format($total, 2);
                            })
                            ->extraAttributes(['class' => 'text-xl font-bold']),
                    ]),

                Forms\Components\Section::make('Adicional')
                    ->schema([
                        Forms\Components\Textarea::make('Observaciones')
                            ->label('Observaciones')
                            ->maxLength(500)
                            ->columnSpanFull(),
                    ]),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn ($query) => $query->activos()->with('proveedor', 'detalles', 'tipoComprobanteGasto', 'motivo', 'cuentaTesoreria'))
            ->columns([
                Tables\Columns\TextColumn::make('FechaEmision')
                    ->label('Fecha Emisión')
                    ->date('d/m/Y')
                    ->sortable(),
                Tables\Columns\TextColumn::make('tipoComprobanteGasto.Nombre')
                    ->label('Tipo Comprobante')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('Numero')
                    ->label('Número')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('proveedor.Nombre')
                    ->label('Proveedor')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('motivo.Nombre')
                    ->label('Motivo')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('detalles_resumen')
                    ->label('Descripción')
                    ->getStateUsing(function ($record) {
                        $descripciones = $record->detalles->pluck('Descripcion')->toArray();
                        $resumen = implode(', ', $descripciones);

                        return strlen($resumen) > 50 ? substr($resumen, 0, 50).'...' : $resumen;
                    })
                    ->wrap(),
                Tables\Columns\TextColumn::make('Total')
                    ->label('Total')
                    ->numeric(2)
                    ->prefix('S/. ')
                    ->sortable(),
                Tables\Columns\TextColumn::make('FuenteTesoreria')
                    ->label('Origen del dinero')
                    ->visible(fn () => static::esPanelGerencia())
                    ->toggleable(),
                Tables\Columns\IconColumn::make('EsGasto')
                    ->label('¿Gasto?')
                    ->boolean()
                    ->trueIcon('heroicon-o-check-badge')
                    ->falseIcon('heroicon-o-x-circle')
                    ->trueColor('success')
                    ->falseColor('danger'),
                Tables\Columns\IconColumn::make('Activo')
                    ->label('Estado')
                    ->boolean()
                    ->sortable(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('SedeID')
                    ->label('Sede')
                    ->options(Sede::where('Activo', true)->pluck('Nombre', 'SedeID'))
                    ->visible(fn () => auth()->user()->esAdmin()),
                Tables\Filters\SelectFilter::make('TipoComprobanteGastoID')
                    ->label('Tipo Comprobante')
                    ->options(TipoComprobanteGasto::where('Activo', true)->pluck('Nombre', 'TipoComprobanteGastoID')),
                Tables\Filters\SelectFilter::make('MotivoID')
                    ->label('Motivo')
                    ->options(Motivo::where('Activo', true)->pluck('Nombre', 'MotivoID')),
                Tables\Filters\Filter::make('FechaEmision')
                    ->form([
                        Forms\Components\DatePicker::make('fecha_desde')
                            ->label('Desde'),
                        Forms\Components\DatePicker::make('fecha_hasta')
                            ->label('Hasta'),
                    ])
                    ->query(function ($query, array $data): void {
                        $query
                            ->when(
                                $data['fecha_desde'],
                                fn ($q) => $q->whereDate('FechaEmision', '>=', $data['fecha_desde'])
                            )
                            ->when(
                                $data['fecha_hasta'],
                                fn ($q) => $q->whereDate('FechaEmision', '<=', $data['fecha_hasta'])
                            );
                    }),
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make()->visible(fn ($record) => static::canEdit($record)),
                Tables\Actions\Action::make('delete')
                    ->visible(fn ($record) => static::canDelete($record))
                    ->label('Eliminar')
                    ->color('danger')
                    ->icon('heroicon-o-trash')
                    ->requiresConfirmation()
                    ->modalHeading('Eliminar Gasto')
                    ->modalDescription('¿Está seguro que desea eliminar este gasto?')
                    ->modalSubmitActionLabel('Sí, eliminar')
                    ->action(function (Gasto $record): void {
                        if ($record->OrigenTesoreriaTipo && (float) $record->Total > 0) {
                            $service = app(\App\Services\TesoreriaGerenciaService::class);
                            $service->revertirEgresoDocumento([
                                'Origen' => $service->referenciaDocumento(
                                    $record->OrigenTesoreriaTipo,
                                    $record->CuentaTesoreriaID
                                ),
                                'Monto' => $record->Total,
                                'FechaContable' => (\App\Services\DateFieldResolver::getFechaAbierta() ?? now())->toDateString(),
                                'TipoDocumento' => \App\Models\MovimientoTesoreria::GASTO,
                                'DocumentoID' => $record->GastoID,
                                'Concepto' => "Extorno por eliminación de gasto #{$record->GastoID}",
                                'Observaciones' => $record->Observaciones,
                            ], auth()->id());
                        }
                        $record->update(['Activo' => false]);
                    })
                    ->successNotificationTitle('Gasto eliminado correctamente'),
            ])
            ->bulkActions([
            ])
            ->defaultSort('FechaEmision', 'desc')
            ->recordUrl(null)
            ->paginationPageOptions([10, 25, 50]);
    }

    public static function canCreate(): bool
    {
        if (! parent::canCreate()) {
            return false;
        }
        if (filament()->getCurrentPanel()?->getId() === 'gerencia') {
            return true;
        }

        return \App\Models\AperturaCierreDia::estaAbierto();
    }

    public static function esPanelGerencia(): bool
    {
        return filament()->getCurrentPanel()?->getId() === 'gerencia';
    }

    public static function canEdit($record): bool
    {
        if (! parent::canEdit($record)) {
            return false;
        }
        if (filament()->getCurrentPanel()?->getId() === 'gerencia') {
            return true;
        }

        return \App\Models\AperturaCierreDia::estaAbierto();
    }

    public static function canDelete($record): bool
    {
        if (! parent::canDelete($record)) {
            return false;
        }
        if (filament()->getCurrentPanel()?->getId() === 'gerencia') {
            return true;
        }

        return \App\Models\AperturaCierreDia::estaAbierto();
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListGastos::route('/'),
            'create' => Pages\CreateGasto::route('/create'),
            'view' => Pages\ViewGasto::route('/{record}'),
            'edit' => Pages\EditGasto::route('/{record}/edit'),
        ];
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }
}
