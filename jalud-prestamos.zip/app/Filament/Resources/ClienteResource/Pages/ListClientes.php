<?php

namespace App\Filament\Resources\ClienteResource\Pages;

use App\Filament\Resources\ClienteResource;
use App\Models\AperturaCierreDia;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;
use Illuminate\Database\Eloquent\Builder;

class ListClientes extends ListRecords
{
    protected static string $resource = ClienteResource::class;

    public function getTitle(): string
    {
        $title = 'Clientes';
        if (!AperturaCierreDia::estaAbierto()) {
            $title .= ' ⚠️ (Día Cerrado)';
        }
        return $title;
    }

    protected function getHeaderActions(): array
    {
        $actions = [];
        
        if (AperturaCierreDia::estaAbierto()) {
            $actions[] = Actions\CreateAction::make()
                ->label('Nuevo Cliente');
        }

        $actions[] = Actions\Action::make('descargar_excel')
            ->label('Descargar Excel')
            ->icon('heroicon-o-arrow-down-tray')
            ->color('success')
            ->url(route('clientes.excel'))
            ->visible(fn() => auth()->user()?->can('descargar_excel_clientes') ?? false);

        $actions[] = Actions\Action::make('descargar_pdf')
            ->label('Descargar PDF')
            ->icon('heroicon-o-eye')
            ->color('danger')
            ->url(route('clientes.pdf'))
            ->openUrlInNewTab()
            ->visible(fn() => auth()->user()?->can('descargar_pdf_clientes') ?? false);
        
        return $actions;
    }

    protected function getTableQuery(): Builder
    {
        $query = parent::getTableQuery();

        $user = auth()->user();
        if ($user?->esPromotorCobrador()) {
            $promotorCobrador = $user->promotorCobrador 
                ?? ($user->PromotorCobradorID ? \App\Models\PromotorCobrador::find($user->PromotorCobradorID) : null);
            
            if ($promotorCobrador && $promotorCobrador->ZonaID) {
                // Filtrar clientes asignados a este promotor o con negocio/créditos activos en su zona
                return $query->where(function (Builder $q) use ($promotorCobrador) {
                    $q->where('PromotorCobradorID', $promotorCobrador->PromotorCobradorID)
                      ->orWhereHas('negocio', function (Builder $nq) use ($promotorCobrador) {
                          $nq->where('ZonaID', $promotorCobrador->ZonaID);
                      })
                      ->orWhereHas('proposiciones', function (Builder $pq) use ($promotorCobrador) {
                          $pq->where('Activo', true)
                             ->where('FueRefinanciada', false)
                             ->where('ZonaID', $promotorCobrador->ZonaID);
                      });
                });
            }

            return $query->whereRaw('1 = 0');
        }

        return $query;
    }
}