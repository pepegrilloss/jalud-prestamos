<?php

namespace App\Filament\Resources\ResolucionExcedenteResource\Pages;

use App\Filament\Resources\ResolucionExcedenteResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditResolucionExcedente extends EditRecord
{
    protected static string $resource = ResolucionExcedenteResource::class;

    protected function mutateFormDataBeforeSave(array $data): array
    {
        if (($data['TipoResolucion'] ?? null) === 'DEVOLUCION_EFECTIVO') {
            $data['ClienteOrigenID'] = null;
            $data['PagoOrigenID'] = null;
        }

        if (($data['TipoResolucion'] ?? null) === 'DEVOLUCION_PAGO_MAYOR') {
            $data['ClienteOrigenID'] = null;
            $data['PagoOrigenID'] = $data['PagoMayorOrigenID'] ?? $data['PagoOrigenID'] ?? null;
            $data['ExcedenteID'] = null;
        }
        unset($data['PagoMayorOrigenID']);

        $data['SedeID'] = $this->record->SedeID;

        $solicitud = $this->record->replicate();
        $solicitud->fill($data);
        app(\App\Services\SedeIntegrityService::class)->assertSolicitudResolucionConsistente($solicitud);

        return $data;
    }

    public function getTitle(): string | \Illuminate\Contracts\Support\Htmlable
    {
        $url = static::getResource()::getUrl('index');
        return new \Illuminate\Support\HtmlString("
            <div class='flex items-center gap-x-3'>
                <a href='{$url}' class='flex items-center justify-center rounded-full p-2 hover:bg-gray-500/5 focus:outline-none focus:ring-2 focus:ring-primary-500/70 transition'>
                    <svg class='w-5 h-5 text-gray-500 dark:text-gray-400' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                        <path stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M10 19l-7-7m0 0l7-7m-7 7h18' />
                    </svg>
                </a>
                <span>Editar Extorno o Devolución</span>
            </div>
        ");
    }

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make()
                ->visible(fn($record) => $record->Estado === 'PENDIENTE'),
        ];
    }
}
