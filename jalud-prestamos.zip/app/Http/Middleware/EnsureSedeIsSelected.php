<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Filament\Facades\Filament;

class EnsureSedeIsSelected
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        // Solo aplicar si el usuario está autenticado en el panel de admin
        if (!auth()->check()) {
            return $next($request);
        }

        $user = auth()->user();
        $path = $request->path();

        // Excluir rutas que no deben ser redirigidas (login, logout, selección de sede, etc.)
        $excludedPaths = [
            'admin/login',
            'admin/logout',
            'admin/select-sede',
            'gerencia',
            'livewire/message/select-sede', // Permitir las llamadas de livewire para esta página
        ];

        foreach ($excludedPaths as $excluded) {
            if (str_starts_with($path, $excluded)) {
                return $next($request);
            }
        }

        // Si ya tiene una sede seleccionada en la sesión, revisar si es Gerencia
        if (session()->exists('sede_activa')) {
            $sedeId = session('sede_activa');
            if ($sedeId) {
                $sede = \App\Models\Sede::find($sedeId);
                // Si la sede activa es Gerencia, no puede entrar a /admin tipeando la URL
                if ($sede && str_contains(strtolower($sede->Nombre), 'gerencia')) {
                    return redirect('/admin/select-sede');
                }
            }
            return $next($request);
        }

        // Si el usuario no es privilegiado y tiene sede asignada, se auto-selecciona
        if (!$user->esAdmin() && !$user->puedeVerTodasLasSedes() && !$user->puedeSeleccionarSedesOperativas() && $user->SedeID) {
            session(['sede_activa' => $user->SedeID]);
            return $next($request);
        }

        // Si es admin o tiene permisos de selección, lo obligamos a pasar por la pantalla de selección
        if ($user->esAdmin() || $user->puedeVerTodasLasSedes() || $user->puedeSeleccionarSedesOperativas()) {
            return redirect('/admin/select-sede');
        }

        // Por defecto, si llegamos aquí y no hay sede, enviamos a seleccionar
        return redirect('/admin/select-sede');
    }
}
